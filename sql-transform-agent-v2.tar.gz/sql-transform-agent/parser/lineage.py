"""
lineage.py

For each DML statement extracted by plsql_splitter, resolve the target
columns to their source columns and expressions using sqlglot.

Outputs a list of LineageRecord objects — one per target column.
This is the deterministic 70% of the transformation-rules Excel.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Set
import sqlglot
from sqlglot import exp


@dataclass
class LineageRecord:
    stmt_id: str
    target_table: str
    target_column: str
    expression: str                          # SQL expression for this column
    source_tables: List[str] = field(default_factory=list)
    source_columns: List[str] = field(default_factory=list)  # "TABLE.COL"
    joins: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)
    stmt_kind: str = ""
    control_context: str = ""


def _collect_joins(select_node: exp.Select) -> List[str]:
    joins = []
    for j in select_node.args.get("joins") or []:
        side = (j.args.get("side") or "").upper()
        kind = (j.args.get("kind") or "").upper()
        jtype = " ".join([p for p in (side, kind, "JOIN") if p])
        tbl = j.this.sql(dialect="oracle")
        on = j.args.get("on")
        on_sql = on.sql(dialect="oracle") if on else ""
        joins.append(f"{jtype} {tbl} ON {on_sql}")
    return joins


def _collect_filters(select_node: exp.Select) -> List[str]:
    where = select_node.args.get("where")
    if not where:
        return []
    # Split top-level AND into separate predicates for readability
    preds = []
    def walk(node):
        if isinstance(node, exp.And):
            walk(node.this)
            walk(node.expression)
        else:
            preds.append(node.sql(dialect="oracle"))
    walk(where.this)
    return preds


def _find_select(node: exp.Expression) -> Optional[exp.Select]:
    # For MERGE: the USING clause is a Subquery/Select
    if isinstance(node, exp.Merge):
        using = node.args.get("using")
        if isinstance(using, exp.Subquery):
            return using.this
        if isinstance(using, exp.Select):
            return using
    if isinstance(node, exp.Insert):
        expr = node.expression
        if isinstance(expr, exp.Select):
            return expr
        if isinstance(expr, exp.Subquery):
            return expr.this
    if isinstance(node, exp.Select):
        return node
    return None


def _source_cols_from_expr(e: exp.Expression, select_scope: exp.Select) -> Set[str]:
    """Collect fully-qualified TABLE.COL refs inside an expression, resolving aliases."""
    # Build alias -> table map from the FROM/JOINs in this select
    alias_map = {}
    from_expr = select_scope.args.get("from")
    if from_expr:
        for src in [from_expr.this] + [j.this for j in (select_scope.args.get("joins") or [])]:
            if isinstance(src, exp.Table):
                alias = src.alias_or_name
                alias_map[alias] = src.name if not src.db else f"{src.db}.{src.name}"
    cols = set()
    for c in e.find_all(exp.Column):
        tbl = c.table
        full_tbl = alias_map.get(tbl, tbl) if tbl else ""
        cols.add(f"{full_tbl}.{c.name}" if full_tbl else c.name)
    return cols


def _source_tables(select_scope: exp.Select) -> List[str]:
    tables = []
    from_expr = select_scope.args.get("from")
    if from_expr:
        for src in [from_expr.this] + [j.this for j in (select_scope.args.get("joins") or [])]:
            if isinstance(src, exp.Table):
                name = src.name if not src.db else f"{src.db}.{src.name}"
                tables.append(name)
    return tables


def extract_lineage(stmt_id: str, sql: str, stmt_kind: str,
                    control_context: str = "") -> List[LineageRecord]:
    try:
        tree = sqlglot.parse_one(sql, dialect="oracle")
    except Exception as e:
        return [LineageRecord(
            stmt_id=stmt_id, target_table="<parse_error>",
            target_column=str(e)[:80], expression=sql[:200],
            stmt_kind=stmt_kind, control_context=control_context,
        )]

    records: List[LineageRecord] = []

    # ---- MERGE ----
    if isinstance(tree, exp.Merge):
        tgt_tbl = tree.this.sql(dialect="oracle")
        sel = _find_select(tree)
        if sel is None:
            return records
        joins = _collect_joins(sel)
        filters = _collect_filters(sel)
        src_tables = _source_tables(sel)

        # Build map of alias -> expression from the USING SELECT list
        projection_map = {}
        for proj in sel.expressions:
            alias = proj.alias_or_name
            inner = proj.this if isinstance(proj, exp.Alias) else proj
            projection_map[alias] = inner

        # Find the WHEN NOT MATCHED INSERT to get target-column ordering,
        # or fall back to the WHEN MATCHED UPDATE SET list.
        target_cols_in_order = []
        for when in tree.args.get("whens", []).expressions if tree.args.get("whens") else []:
            pass  # sqlglot exposes whens differently per version; handled below

        # sqlglot represents WHENs as a list under tree.args["whens"]
        whens = tree.args.get("whens")
        when_list = whens.expressions if whens else []
        for when in when_list:
            then = when.args.get("then")
            if isinstance(then, exp.Insert):
                cols_node = then.this
                if isinstance(cols_node, exp.Schema):
                    target_cols_in_order = [c.name for c in cols_node.expressions]
                values = then.expression
                # VALUES (...) references the source aliases
                src_values = []
                if isinstance(values, exp.Values):
                    tup = values.expressions[0]
                    src_values = [v.sql(dialect="oracle") for v in tup.expressions]
                for tgt_col, src_ref in zip(target_cols_in_order, src_values):
                    # src_ref looks like "src.account_id" — strip prefix, look up expr
                    alias_key = src_ref.split(".")[-1]
                    inner = projection_map.get(alias_key)
                    expr_sql = inner.sql(dialect="oracle") if inner else src_ref
                    src_cols = sorted(_source_cols_from_expr(inner, sel)) if inner else []
                    records.append(LineageRecord(
                        stmt_id=stmt_id, target_table=tgt_tbl,
                        target_column=tgt_col, expression=expr_sql,
                        source_tables=src_tables, source_columns=src_cols,
                        joins=joins, filters=filters,
                        stmt_kind="MERGE", control_context=control_context,
                    ))
                break  # first INSERT when-clause is enough for target col set

    # ---- INSERT ... SELECT ----
    elif isinstance(tree, exp.Insert):
        tgt_tbl_node = tree.this
        if isinstance(tgt_tbl_node, exp.Schema):
            tgt_tbl = tgt_tbl_node.this.sql(dialect="oracle")
            target_cols = [c.name for c in tgt_tbl_node.expressions]
        else:
            tgt_tbl = tgt_tbl_node.sql(dialect="oracle")
            target_cols = []
        sel = _find_select(tree)
        if sel is None:
            # INSERT ... VALUES
            values = tree.expression
            if isinstance(values, exp.Values) and target_cols:
                tup = values.expressions[0]
                for col, val in zip(target_cols, tup.expressions):
                    records.append(LineageRecord(
                        stmt_id=stmt_id, target_table=tgt_tbl, target_column=col,
                        expression=val.sql(dialect="oracle"),
                        stmt_kind="INSERT", control_context=control_context,
                    ))
            return records
        joins = _collect_joins(sel)
        filters = _collect_filters(sel)
        src_tables = _source_tables(sel)
        for i, proj in enumerate(sel.expressions):
            inner = proj.this if isinstance(proj, exp.Alias) else proj
            tgt_col = target_cols[i] if i < len(target_cols) else proj.alias_or_name
            records.append(LineageRecord(
                stmt_id=stmt_id, target_table=tgt_tbl, target_column=tgt_col,
                expression=inner.sql(dialect="oracle"),
                source_tables=src_tables,
                source_columns=sorted(_source_cols_from_expr(inner, sel)),
                joins=joins, filters=filters,
                stmt_kind="INSERT", control_context=control_context,
            ))

    # ---- UPDATE ----
    elif isinstance(tree, exp.Update):
        tgt_tbl = tree.this.sql(dialect="oracle")
        # sqlglot exposes SET as tree.expressions = list of EQ nodes
        where = tree.args.get("where")
        filters = [where.this.sql(dialect="oracle")] if where else []
        for eq in tree.expressions:
            col = eq.this.sql(dialect="oracle")
            val = eq.expression
            records.append(LineageRecord(
                stmt_id=stmt_id, target_table=tgt_tbl, target_column=col,
                expression=val.sql(dialect="oracle"),
                filters=filters, stmt_kind="UPDATE",
                control_context=control_context,
            ))

    # ---- DELETE ----
    elif isinstance(tree, exp.Delete):
        tgt_tbl = tree.this.sql(dialect="oracle")
        where = tree.args.get("where")
        filters = [where.this.sql(dialect="oracle")] if where else []
        records.append(LineageRecord(
            stmt_id=stmt_id, target_table=tgt_tbl, target_column="<DELETE>",
            expression="(row deletion)", filters=filters,
            stmt_kind="DELETE", control_context=control_context,
        ))

    return records
