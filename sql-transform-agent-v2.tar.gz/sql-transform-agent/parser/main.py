"""
main.py — CLI entry point.

Usage:
    python main.py path/to/proc.sql \
        --server http://127.0.0.1:8080 \
        --model qwen2.5-coder \
        --out rules.xlsx

If --skip-llm is given, the Excel is produced with empty enrichment columns
(useful to validate the deterministic lineage pass alone).
"""
from __future__ import annotations
import argparse
import sys
from dataclasses import asdict
from pathlib import Path

# make sibling imports work when run as `python main.py`
sys.path.insert(0, str(Path(__file__).parent))

from plsql_splitter import split_plsql
from lineage import extract_lineage
from llm_enricher import enrich_all
from excel_writer import write_workbook


def run(sql_path: str, out_path: str, server_url: str, model: str,
        skip_llm: bool = False) -> str:
    text = Path(sql_path).read_text()
    stmts = split_plsql(text)
    print(f"Found {len(stmts)} DML statements")

    all_lineage = []
    for s in stmts:
        recs = extract_lineage(s.stmt_id, s.sql, s.kind, s.control_context)
        print(f"  {s.stmt_id}: {len(recs)} target columns")
        all_lineage.extend(recs)

    if skip_llm:
        enriched = []
        for r in all_lineage:
            d = asdict(r)
            d.update({
                "transformation_type": "", "business_rule": "",
                "null_handling": "", "data_quality_notes": "",
            })
            enriched.append(d)
    else:
        print(f"Enriching {len(all_lineage)} records via {server_url} ...")
        enriched = enrich_all(all_lineage, server_url, model)

    proc_name = stmts[0].proc_name if stmts else "UNKNOWN"
    proc_params = stmts[0].proc_params if stmts else []
    write_workbook(
        out_path=out_path,
        proc_name=proc_name or "UNKNOWN",
        proc_params=proc_params,
        statements=[asdict(s) for s in stmts],
        enriched=enriched,
    )
    print(f"Wrote {out_path}")
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sql_file")
    ap.add_argument("--server", default="http://127.0.0.1:8080")
    ap.add_argument("--model", default="qwen2.5-coder")
    ap.add_argument("--out", default="transformation_rules.xlsx")
    ap.add_argument("--skip-llm", action="store_true")
    args = ap.parse_args()
    run(args.sql_file, args.out, args.server, args.model, args.skip_llm)


if __name__ == "__main__":
    main()
