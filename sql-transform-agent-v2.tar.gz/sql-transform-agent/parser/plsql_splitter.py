"""
plsql_splitter.py

Splits an Oracle PL/SQL file into a list of analyzable DML statements
(INSERT / UPDATE / DELETE / MERGE / standalone SELECT), each with the
surrounding procedural context (containing IF branch, loop, proc params).

sqlglot does not robustly parse PL/SQL control flow, so we do a lightweight
lexical pass first, then hand each extracted SQL statement to sqlglot.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import List, Optional


DML_START = re.compile(
    r"\b(MERGE\s+INTO|INSERT\s+INTO|UPDATE|DELETE\s+FROM|SELECT)\b",
    re.IGNORECASE,
)

# Strip single-line comments and /* ... */ blocks, but keep line numbers.
_LINE_COMMENT = re.compile(r"--[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)


@dataclass
class PlsqlStatement:
    stmt_id: str
    kind: str                         # MERGE / INSERT / UPDATE / DELETE / SELECT
    sql: str                          # the extracted SQL, semicolon-terminated
    line_start: int
    line_end: int
    proc_name: Optional[str] = None
    proc_params: List[str] = field(default_factory=list)
    control_context: str = ""         # e.g. "inside IF p_run_mode = 'FULL'"


def _strip_comments(text: str) -> str:
    text = _BLOCK_COMMENT.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    text = _LINE_COMMENT.sub("", text)
    return text


def _find_proc_header(text: str):
    m = re.search(
        r"CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+([A-Z0-9_.]+)\s*\((.*?)\)\s*(?:AS|IS)",
        text, re.IGNORECASE | re.DOTALL,
    )
    if not m:
        return None, []
    name = m.group(1)
    params_raw = m.group(2).strip()
    params = []
    if params_raw:
        for p in re.split(r",\s*(?![^()]*\))", params_raw):
            p = " ".join(p.split())
            if p:
                params.append(p)
    return name, params


def _extract_statement(text: str, start: int) -> tuple[str, int]:
    """
    From position `start` (which points at a DML keyword), walk forward and
    return (statement_text, end_pos). A PL/SQL DML statement ends at the
    first semicolon that is not inside parentheses or a string literal.
    """
    depth = 0
    i = start
    n = len(text)
    in_str = False
    while i < n:
        ch = text[i]
        if ch == "'" and (i == 0 or text[i - 1] != "\\"):
            in_str = not in_str
        elif not in_str:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == ";" and depth == 0:
                return text[start:i + 1], i + 1
        i += 1
    return text[start:], n


def _control_context_at(text: str, pos: int) -> str:
    """Heuristic: find the nearest enclosing IF/LOOP/WHILE before `pos`."""
    prefix = text[:pos].upper()
    depth = 0
    for m in reversed(list(re.finditer(r"\b(IF|LOOP|WHILE|END\s+IF|END\s+LOOP)\b", prefix))):
        token = re.sub(r"\s+", " ", m.group(0))
        if token.startswith("END"):
            depth += 1
        else:
            if depth == 0:
                # Grab the condition/header line
                line_start = prefix.rfind("\n", 0, m.start()) + 1
                line_end = prefix.find("\n", m.end())
                if line_end == -1:
                    line_end = len(prefix)
                line = text[line_start:line_end].strip().rstrip(" THEN").rstrip()
                return f"inside {line}"
            depth -= 1
    return "top-level"


def split_plsql(text: str) -> List[PlsqlStatement]:
    clean = _strip_comments(text)
    proc_name, params = _find_proc_header(clean)

    statements: List[PlsqlStatement] = []
    pos = 0
    idx = 0
    while True:
        m = DML_START.search(clean, pos)
        if not m:
            break
        # Skip SELECTs that are part of a surrounding DML we've already captured
        start = m.start()
        sql, end = _extract_statement(clean, start)
        line_start = clean.count("\n", 0, start) + 1
        line_end = clean.count("\n", 0, end) + 1

        kind = m.group(1).upper().split()[0]
        if kind == "MERGE":
            kind = "MERGE"
        elif kind == "DELETE":
            kind = "DELETE"
        elif kind == "INSERT":
            kind = "INSERT"
        elif kind == "UPDATE":
            kind = "UPDATE"
        else:
            kind = "SELECT"

        idx += 1
        statements.append(PlsqlStatement(
            stmt_id=f"{proc_name or 'anon'}.stmt_{idx:02d}",
            kind=kind,
            sql=sql.strip(),
            line_start=line_start,
            line_end=line_end,
            proc_name=proc_name,
            proc_params=params,
            control_context=_control_context_at(clean, start),
        ))
        pos = end
    return statements


if __name__ == "__main__":
    import sys
    with open(sys.argv[1]) as f:
        stmts = split_plsql(f.read())
    for s in stmts:
        print(f"{s.stmt_id:40s} {s.kind:8s} lines {s.line_start}-{s.line_end}  [{s.control_context}]")
