"""
llm_enricher.py  (v2 — business-language prompt)
"""
from __future__ import annotations
import json, re
from dataclasses import asdict
from typing import List, Dict, Any
import urllib.request, urllib.error
from lineage import LineageRecord


PROMPT_TEMPLATE = """You are documenting an Oracle PL/SQL to SEI SWP migration for three audiences:
business analysts, SEI counterparts, and internal auditors. Write for a reader
who understands finance but NOT SQL.

TARGET: {target_table}.{target_column}
SQL EXPRESSION: {expression}
SOURCE COLUMNS: {source_columns}
JOIN CONTEXT: {joins}
FILTER CONTEXT: {filters}
PROCEDURAL CONTEXT: {control_context}

Return ONLY this JSON (no SQL syntax in field VALUES — describe in plain English).
Do NOT write "CASE WHEN", "COALESCE", "LEFT JOIN", etc., in the rule text.

{{
  "field_description": "<what this field represents, max 20 words>",
  "transformation_rule_plain": "<plain-English rule, no SQL keywords, max 40 words>",
  "business_conditions": "<which rows qualify for this load, plain English>",
  "null_behavior_plain": "<when and why this field can be NULL, plain English>",
  "load_condition": "<always, or: only when <condition>>",
  "dq_risk": "<one specific risk in plain English, or 'none'>",
  "dq_impact": "<business impact if risk materializes, or 'none'>",
  "dq_severity": "LOW | MEDIUM | HIGH | NONE",
  "transformation_category": "DIRECT | DERIVED | LOOKUP | CONDITIONAL | AGGREGATED | CONSTANT | SYSTEM",
  "source_authority": "<which source system is authoritative for this field>"
}}"""


def _post(url, payload, timeout=120):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _extract_json(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.MULTILINE)
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        raise ValueError(f"no JSON in response: {text[:200]}")
    return json.loads(m.group(0))


def enrich_record(rec: LineageRecord, server_url: str, model: str = "qwen2.5-coder") -> Dict[str, Any]:
    prompt = PROMPT_TEMPLATE.format(
        target_table=rec.target_table, target_column=rec.target_column,
        expression=rec.expression,
        source_columns=", ".join(rec.source_columns) or "(none)",
        joins="; ".join(rec.joins) or "(none)",
        filters="; ".join(rec.filters) or "(none)",
        control_context=rec.control_context or "top-level",
    )
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You output strict JSON only. No SQL syntax in JSON values."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1, "max_tokens": 600,
        "response_format": {"type": "json_object"},
    }
    try:
        resp = _post(f"{server_url}/v1/chat/completions", payload)
        return _extract_json(resp["choices"][0]["message"]["content"])
    except (urllib.error.URLError, KeyError, ValueError) as e:
        return {
            "field_description": "(LLM enrichment failed — review manually)",
            "transformation_rule_plain": f"(error: {e})",
            "business_conditions": "", "null_behavior_plain": "",
            "load_condition": "", "dq_risk": "LLM call failed",
            "dq_impact": "Field documentation incomplete",
            "dq_severity": "MEDIUM", "transformation_category": "UNKNOWN",
            "source_authority": "unknown",
        }


def enrich_all(records, server_url, model="qwen2.5-coder"):
    out = []
    for i, rec in enumerate(records, 1):
        print(f"  [{i}/{len(records)}] {rec.target_table}.{rec.target_column}")
        d = asdict(rec)
        d.update(enrich_record(rec, server_url, model))
        out.append(d)
    return out
