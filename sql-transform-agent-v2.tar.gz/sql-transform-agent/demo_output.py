"""
demo_output.py  (v2)

Generates a sample transformation_rules.xlsx using hand-built data that
mirrors what the real pipeline (sqlglot + Qwen w/ business prompt) would
produce for sample/load_positions.sql.
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / "parser"))
from excel_writer import write_workbook

proc_name = "SWP_STG.LOAD_DAILY_POSITIONS"
proc_params = ["p_run_date IN DATE", "p_run_mode IN VARCHAR2 DEFAULT 'INCREMENTAL'"]

statements = [
    {"stmt_id": "SWP_STG.LOAD_DAILY_POSITIONS.stmt_01", "kind": "DELETE",
     "line_start": 12, "line_end": 12,
     "control_context": "inside IF p_run_mode = 'FULL'"},
    {"stmt_id": "SWP_STG.LOAD_DAILY_POSITIONS.stmt_02", "kind": "MERGE",
     "line_start": 15, "line_end": 70, "control_context": "top-level"},
    {"stmt_id": "SWP_STG.LOAD_DAILY_POSITIONS.stmt_03", "kind": "INSERT",
     "line_start": 74, "line_end": 75, "control_context": "top-level"},
]

MERGE_ID = "SWP_STG.LOAD_DAILY_POSITIONS.stmt_02"
AUDIT_ID = "SWP_STG.LOAD_DAILY_POSITIONS.stmt_03"
DELETE_ID = "SWP_STG.LOAD_DAILY_POSITIONS.stmt_01"

merge_joins = [
    "LEFT JOIN SWP_STG.FX_RATES fx ON fx.from_ccy = p.ccy_code AND fx.to_ccy = 'USD' AND fx.rate_date = p.position_date",
    "LEFT JOIN SWP_STG.SECURITY_MASTER sm ON sm.security_id = p.security_id",
]
merge_filters = [
    "p.position_date = p_run_date",
    "p.status = 'ACTIVE'",
    "p.quantity <> 0",
]
merge_src_tables = ["SWP_STG.POSITIONS_BRONZE", "SWP_STG.FX_RATES", "SWP_STG.SECURITY_MASTER"]

def m(col, expr, srcs, **kw):
    """Build a MERGE enrichment record with business-language fields."""
    base = {
        "stmt_id": MERGE_ID, "stmt_kind": "MERGE",
        "target_table": "SWP_STG.POSITIONS_GOLD", "target_column": col,
        "expression": expr,
        "source_tables": merge_src_tables, "source_columns": srcs,
        "joins": merge_joins, "filters": merge_filters,
        "control_context": "top-level",
        "business_conditions": "Active positions for the run date with non-zero quantity.",
        "load_condition": "Always (merged each run)",
        "dq_risk": "none", "dq_impact": "none", "dq_severity": "NONE",
    }
    base.update(kw)
    return base

enriched = [
    # DELETE
    {"stmt_id": DELETE_ID, "stmt_kind": "DELETE",
     "target_table": "SWP_STG.POSITIONS_GOLD", "target_column": "<DELETE>",
     "expression": "(row deletion)",
     "source_tables": [], "source_columns": [],
     "joins": [], "filters": ["position_date = p_run_date"],
     "control_context": "inside IF p_run_mode = 'FULL'",
     "field_description": "Removes existing rows for the run date before a full reload.",
     "transformation_rule_plain": "When the run mode is FULL, all existing rows for the run date are deleted before the merge reloads them.",
     "business_conditions": "Only when the caller requests a full reload.",
     "null_behavior_plain": "Not applicable — this is a row deletion, not a field load.",
     "load_condition": "Only when p_run_mode = 'FULL'",
     "dq_risk": "Destructive operation depends on the caller passing the correct run mode.",
     "dq_impact": "Accidental full reload would erase in-day corrections.",
     "dq_severity": "HIGH",
     "transformation_category": "SYSTEM",
     "source_authority": "Procedure parameter"},

    m("account_id", "p.account_id", ["SWP_STG.POSITIONS_BRONZE.account_id"],
      field_description="Account holding the position.",
      transformation_rule_plain="Taken directly from the AddVantage positions feed without change.",
      null_behavior_plain="Will not be NULL; part of the merge key.",
      transformation_category="DIRECT",
      source_authority="AddVantage (POSITIONS_BRONZE)"),

    m("security_id", "p.security_id", ["SWP_STG.POSITIONS_BRONZE.security_id"],
      field_description="Internal identifier of the security held.",
      transformation_rule_plain="Taken directly from the AddVantage positions feed without change.",
      null_behavior_plain="Will not be NULL; part of the merge key.",
      transformation_category="DIRECT",
      source_authority="AddVantage (POSITIONS_BRONZE)"),

    m("position_date", "p.position_date", ["SWP_STG.POSITIONS_BRONZE.position_date"],
      field_description="As-of date of the position snapshot.",
      transformation_rule_plain="Taken directly from the AddVantage positions feed.",
      null_behavior_plain="Will not be NULL; part of the merge key and filter.",
      transformation_category="DIRECT",
      source_authority="AddVantage (POSITIONS_BRONZE)"),

    m("currency_code", "UPPER(TRIM(p.ccy_code))", ["SWP_STG.POSITIONS_BRONZE.ccy_code"],
      field_description="Currency in which the position is denominated.",
      transformation_rule_plain="The source currency code is trimmed of whitespace and converted to uppercase.",
      null_behavior_plain="Not expected to be NULL; NULL source would pass through as NULL.",
      transformation_category="DERIVED",
      source_authority="AddVantage (POSITIONS_BRONZE)",
      dq_risk="No validation against a standard currency reference list.",
      dq_impact="Invalid or misspelled currency codes would flow through and cause FX-rate lookup to fail.",
      dq_severity="MEDIUM"),

    m("quantity", "p.quantity", ["SWP_STG.POSITIONS_BRONZE.quantity"],
      field_description="Quantity held; negative values indicate short positions.",
      transformation_rule_plain="Taken directly from the AddVantage positions feed.",
      null_behavior_plain="Positions with zero quantity are excluded upstream.",
      transformation_category="DIRECT",
      source_authority="AddVantage (POSITIONS_BRONZE)"),

    m("market_value_usd",
      "CASE WHEN p.ccy_code = 'USD' THEN p.market_value WHEN fx.rate IS NOT NULL THEN p.market_value * fx.rate ELSE NULL END",
      ["SWP_STG.POSITIONS_BRONZE.ccy_code", "SWP_STG.POSITIONS_BRONZE.market_value", "SWP_STG.FX_RATES.rate"],
      field_description="Market value of the position expressed in US dollars.",
      transformation_rule_plain="If the position is already in USD, the market value is used as-is. Otherwise, the market value is multiplied by the USD FX rate for the position date.",
      null_behavior_plain="Empty when the position is in a non-USD currency and no FX rate exists for that currency and date.",
      transformation_category="CONDITIONAL",
      source_authority="AddVantage market value; FX Rates Service for conversion",
      dq_risk="Missing FX rate silently produces an empty USD market value with no alert.",
      dq_impact="Under-reported AUM and incorrect P&L for the affected rows.",
      dq_severity="HIGH"),

    m("cost_basis", "COALESCE(p.cost_basis, 0)", ["SWP_STG.POSITIONS_BRONZE.cost_basis"],
      field_description="Original cost basis of the position in source currency.",
      transformation_rule_plain="Missing cost basis is treated as zero; otherwise the source value is used.",
      null_behavior_plain="Never NULL; defaults to zero when the source is missing.",
      transformation_category="DERIVED",
      source_authority="AddVantage (POSITIONS_BRONZE)",
      dq_risk="Defaulting missing values to zero masks genuine data-quality gaps.",
      dq_impact="Understated cost basis and overstated unrealized gains for affected rows.",
      dq_severity="MEDIUM"),

    m("unrealized_pnl",
      "CASE WHEN p.market_value IS NULL OR p.cost_basis IS NULL THEN NULL ELSE p.market_value - p.cost_basis END",
      ["SWP_STG.POSITIONS_BRONZE.market_value", "SWP_STG.POSITIONS_BRONZE.cost_basis"],
      field_description="Unrealized profit or loss in the position's source currency.",
      transformation_rule_plain="Subtracts the cost basis from the market value. Returns empty when either input is missing.",
      null_behavior_plain="Empty when market value or cost basis is missing in the source.",
      transformation_category="CONDITIONAL",
      source_authority="AddVantage (POSITIONS_BRONZE)",
      dq_risk="Calculated in source currency, inconsistent with market_value_usd which is USD.",
      dq_impact="Downstream reporting may mix currencies when comparing value and P&L.",
      dq_severity="MEDIUM"),

    m("asset_class", "sm.asset_class", ["SWP_STG.SECURITY_MASTER.asset_class"],
      field_description="Asset class classification of the held security.",
      transformation_rule_plain="Looked up from the Security Master using the security identifier.",
      null_behavior_plain="Empty when the security is not present in the Security Master.",
      transformation_category="LOOKUP",
      source_authority="Security Master",
      dq_risk="Unmatched securities silently yield an empty asset class.",
      dq_impact="Positions in unclassified securities will not appear in asset-class reporting.",
      dq_severity="MEDIUM"),

    m("issuer_name", "sm.issuer_name", ["SWP_STG.SECURITY_MASTER.issuer_name"],
      field_description="Name of the security's issuer.",
      transformation_rule_plain="Looked up from the Security Master using the security identifier.",
      null_behavior_plain="Empty when the security is not present in the Security Master.",
      transformation_category="LOOKUP",
      source_authority="Security Master",
      dq_risk="Unmatched securities silently yield an empty issuer name.",
      dq_impact="Issuer-level exposure reports will omit affected positions.",
      dq_severity="MEDIUM"),

    m("position_type", "CASE WHEN p.quantity < 0 THEN 'SHORT' ELSE 'LONG' END",
      ["SWP_STG.POSITIONS_BRONZE.quantity"],
      field_description="Classifies the position as either LONG or SHORT.",
      transformation_rule_plain="Negative quantities are classified as SHORT, all others as LONG.",
      null_behavior_plain="Never NULL; zero-quantity rows are excluded upstream.",
      transformation_category="CONDITIONAL",
      source_authority="Derived from AddVantage quantity"),

    m("load_timestamp", "SYSDATE", [],
      field_description="System timestamp recording when the row was loaded.",
      transformation_rule_plain="The database system time at the moment of load is written to this field.",
      null_behavior_plain="Never NULL.",
      transformation_category="SYSTEM",
      source_authority="Database system time",
      dq_risk="Different servers or time zones can produce inconsistent timestamps.",
      dq_impact="Audit trail may appear out of order across environments.",
      dq_severity="LOW"),

    m("effective_date", "p_run_date", [],
      field_description="Business-effective date applied to all rows in this batch.",
      transformation_rule_plain="The run date passed to the procedure is applied to every row in the batch.",
      null_behavior_plain="Never NULL; required procedure parameter.",
      transformation_category="CONSTANT",
      source_authority="Procedure parameter"),

    # Audit INSERT
    {"stmt_id": AUDIT_ID, "stmt_kind": "INSERT",
     "target_table": "SWP_STG.LOAD_AUDIT", "target_column": "run_date",
     "expression": "p_run_date",
     "source_tables": [], "source_columns": [],
     "joins": [], "filters": [], "control_context": "top-level",
     "field_description": "Run date for this audit entry.",
     "transformation_rule_plain": "Set from the procedure's run date parameter.",
     "business_conditions": "Written after every successful merge.",
     "null_behavior_plain": "Never NULL.",
     "load_condition": "Always",
     "dq_risk": "none", "dq_impact": "none", "dq_severity": "NONE",
     "transformation_category": "CONSTANT",
     "source_authority": "Procedure parameter"},

    {"stmt_id": AUDIT_ID, "stmt_kind": "INSERT",
     "target_table": "SWP_STG.LOAD_AUDIT", "target_column": "proc_name",
     "expression": "'LOAD_DAILY_POSITIONS'",
     "source_tables": [], "source_columns": [],
     "joins": [], "filters": [], "control_context": "top-level",
     "field_description": "Name of the procedure writing this audit row.",
     "transformation_rule_plain": "Hard-coded literal identifying the procedure.",
     "business_conditions": "Written after every successful merge.",
     "null_behavior_plain": "Never NULL.",
     "load_condition": "Always",
     "dq_risk": "Hard-coded name can drift if the procedure is renamed.",
     "dq_impact": "Audit log would report an incorrect procedure name.",
     "dq_severity": "LOW",
     "transformation_category": "CONSTANT",
     "source_authority": "Code constant"},

    {"stmt_id": AUDIT_ID, "stmt_kind": "INSERT",
     "target_table": "SWP_STG.LOAD_AUDIT", "target_column": "row_count",
     "expression": "v_row_count",
     "source_tables": [], "source_columns": [],
     "joins": [], "filters": [], "control_context": "top-level",
     "field_description": "Number of rows affected by the merge.",
     "transformation_rule_plain": "Count of rows written or updated during the merge, captured from the database.",
     "business_conditions": "Written after every successful merge.",
     "null_behavior_plain": "Never NULL; defaults to zero.",
     "load_condition": "Always",
     "dq_risk": "none", "dq_impact": "none", "dq_severity": "NONE",
     "transformation_category": "DERIVED",
     "source_authority": "Database row count"},

    {"stmt_id": AUDIT_ID, "stmt_kind": "INSERT",
     "target_table": "SWP_STG.LOAD_AUDIT", "target_column": "run_mode",
     "expression": "p_run_mode",
     "source_tables": [], "source_columns": [],
     "joins": [], "filters": [], "control_context": "top-level",
     "field_description": "Run mode used for this load (FULL or INCREMENTAL).",
     "transformation_rule_plain": "Set from the procedure's run mode parameter.",
     "business_conditions": "Written after every successful merge.",
     "null_behavior_plain": "Never NULL; defaults to INCREMENTAL.",
     "load_condition": "Always",
     "dq_risk": "none", "dq_impact": "none", "dq_severity": "NONE",
     "transformation_category": "CONSTANT",
     "source_authority": "Procedure parameter"},
]

out_path = "/mnt/user-data/outputs/transformation_rules_v2.xlsx"
Path(out_path).parent.mkdir(parents=True, exist_ok=True)
write_workbook(out_path, proc_name, proc_params, statements, enriched)
print(f"Wrote {out_path}")
