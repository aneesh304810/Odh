-- Sample PL/SQL procedure: loads daily positions from AddVantage staging
-- into the SWP target model. Representative of BBH migration patterns.

CREATE OR REPLACE PROCEDURE SWP_STG.LOAD_DAILY_POSITIONS (
    p_run_date  IN DATE,
    p_run_mode  IN VARCHAR2 DEFAULT 'INCREMENTAL'
) AS
    v_row_count NUMBER := 0;
BEGIN

    IF p_run_mode = 'FULL' THEN
        DELETE FROM SWP_STG.POSITIONS_GOLD WHERE position_date = p_run_date;
    END IF;

    MERGE INTO SWP_STG.POSITIONS_GOLD tgt
    USING (
        SELECT
            p.account_id                                          AS account_id,
            p.security_id                                         AS security_id,
            p.position_date                                       AS position_date,
            UPPER(TRIM(p.ccy_code))                               AS currency_code,
            p.quantity                                            AS quantity,
            CASE
                WHEN p.ccy_code = 'USD' THEN p.market_value
                WHEN fx.rate IS NOT NULL THEN p.market_value * fx.rate
                ELSE NULL
            END                                                   AS market_value_usd,
            COALESCE(p.cost_basis, 0)                             AS cost_basis,
            CASE
                WHEN p.market_value IS NULL OR p.cost_basis IS NULL THEN NULL
                ELSE p.market_value - p.cost_basis
            END                                                   AS unrealized_pnl,
            sm.asset_class                                        AS asset_class,
            sm.issuer_name                                        AS issuer_name,
            CASE WHEN p.quantity < 0 THEN 'SHORT' ELSE 'LONG' END AS position_type,
            SYSDATE                                               AS load_timestamp,
            p_run_date                                            AS effective_date
        FROM SWP_STG.POSITIONS_BRONZE p
        LEFT JOIN SWP_STG.FX_RATES fx
               ON fx.from_ccy = p.ccy_code
              AND fx.to_ccy   = 'USD'
              AND fx.rate_date = p.position_date
        LEFT JOIN SWP_STG.SECURITY_MASTER sm
               ON sm.security_id = p.security_id
        WHERE p.position_date = p_run_date
          AND p.status = 'ACTIVE'
          AND p.quantity <> 0
    ) src
    ON (tgt.account_id   = src.account_id
    AND tgt.security_id  = src.security_id
    AND tgt.position_date = src.position_date)
    WHEN MATCHED THEN UPDATE SET
        tgt.currency_code    = src.currency_code,
        tgt.quantity         = src.quantity,
        tgt.market_value_usd = src.market_value_usd,
        tgt.cost_basis       = src.cost_basis,
        tgt.unrealized_pnl   = src.unrealized_pnl,
        tgt.asset_class      = src.asset_class,
        tgt.issuer_name      = src.issuer_name,
        tgt.position_type    = src.position_type,
        tgt.load_timestamp   = src.load_timestamp
    WHEN NOT MATCHED THEN INSERT (
        account_id, security_id, position_date, currency_code, quantity,
        market_value_usd, cost_basis, unrealized_pnl, asset_class,
        issuer_name, position_type, load_timestamp, effective_date
    ) VALUES (
        src.account_id, src.security_id, src.position_date, src.currency_code, src.quantity,
        src.market_value_usd, src.cost_basis, src.unrealized_pnl, src.asset_class,
        src.issuer_name, src.position_type, src.load_timestamp, src.effective_date
    );

    v_row_count := SQL%ROWCOUNT;

    INSERT INTO SWP_STG.LOAD_AUDIT (run_date, proc_name, row_count, run_mode)
    VALUES (p_run_date, 'LOAD_DAILY_POSITIONS', v_row_count, p_run_mode);

    COMMIT;
END LOAD_DAILY_POSITIONS;
/
