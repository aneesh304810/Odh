# SQL Transform Agent

Parses Oracle PL/SQL procedures and produces a transformation-rules Excel
workbook documenting source→target lineage, business rules, joins, filters,
and control flow.

## Architecture

```
 .sql file
     │
     ▼
 plsql_splitter.py   ── extracts DML statements + control-flow context
     │                  (regex/state-machine, NOT sqlglot — PL/SQL control
     │                  flow is not reliably parsed by sqlglot)
     ▼
 lineage.py          ── sqlglot AST walk per statement; resolves every
     │                  target column to its source columns + expression
     ▼
 llm_enricher.py     ── calls local Qwen via llama-cpp-python OpenAI API
     │                  for each target column: transformation_type,
     │                  business_rule, null_handling, dq_notes
     ▼
 excel_writer.py     ── multi-sheet xlsx: Summary / Lineage / Joins /
                        Filters / Procedural_Logic
```

## One-time setup

```bash
pip install sqlglot openpyxl
```

Start your Qwen server (you already have this running):

```bash
python -m llama_cpp.server \
  --model qwen2.5-coder-14b-instruct-q4_k_m.gguf \
  --n_gpu_layers -1 \
  --host 127.0.0.1 --port 8080 \
  --chat_format qwen \
  --n_ctx 8192
```

## Usage

```bash
# Validate the deterministic lineage pass first (no LLM needed)
python parser/main.py sample/load_positions.sql --skip-llm --out rules.xlsx

# Full run with LLM enrichment
python parser/main.py sample/load_positions.sql \
  --server http://127.0.0.1:8080 \
  --model qwen2.5-coder \
  --out rules.xlsx
```

## Why this design

1. **PL/SQL splitter is lexical, not sqlglot.** sqlglot's Oracle dialect
   handles SELECT/DML well but is unreliable on BEGIN/END, cursors, and
   IF/LOOP. We split lexically and only hand individual DML statements to
   sqlglot.

2. **Lineage is deterministic.** The Lineage sheet is produced entirely from
   the AST with no LLM involvement. It is the source of truth — the LLM
   can only add classification labels and descriptions on top, never
   invent column names.

3. **LLM is called per column, not per proc.** Each call is ~500 tokens in,
   ~200 out. On a Blackwell 1000 running Qwen2.5-Coder-14B Q4 you'll get
   15–25 tok/s, so a 200-column proc takes 5–10 minutes. Keeps you well
   inside the model's sweet spot for Q4 quality.

4. **Strict JSON output via `response_format`.** llama-cpp-python supports
   `{"response_format": {"type": "json_object"}}` which applies a GBNF
   grammar constraint — this eliminates 90%+ of the malformed-JSON
   retries you'd otherwise hit with a Q4 model.

## Tuning tips

- **Parallelism.** llama-cpp-python server supports multiple slots.
  Add `--n_parallel 3` when launching; then in `llm_enricher.py` swap
  the serial loop for `concurrent.futures.ThreadPoolExecutor(max_workers=3)`.
  Cuts wall time 2-3x.
- **Prompt size.** If procs push prompt > 2K tokens, truncate the
  `joins` and `filters` fields in the prompt to the 3 most relevant for
  that target column (match on shared source tables).
- **Context window.** `--n_ctx 8192` is plenty per call. Don't go higher
  on 8GB VRAM — KV cache will push you out of VRAM.
- **Dialect fallbacks.** If sqlglot fails on a specific statement,
  `lineage.py` emits a `<parse_error>` row rather than crashing. Review
  those manually.

## Next steps

Once you're happy with the Excel format:

1. Wrap `main.py` in a VS Code extension (TS) that spawns the Python
   sidecar and opens the .xlsx on completion.
2. Add a `snapshots/` folder to the output and save each run's JSON —
   enables diffing transformation rules across migration iterations.
3. For the full AddVantage deconversion, run the CLI across all procs
   in parallel via GNU parallel, one llama-server slot per worker.
